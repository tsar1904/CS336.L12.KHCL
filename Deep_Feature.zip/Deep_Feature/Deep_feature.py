from tensorflow.keras.applications.vgg16 import VGG16
from tensorflow.keras.preprocessing.image import load_img,img_to_array
from tensorflow.keras.applications.vgg16 import preprocess_input
from tensorflow.keras.models import Model
import matplotlib.pyplot as plt
import os,sys
import numpy as np

model = VGG16()
# only select f2
model = Model(inputs=model.inputs, outputs=model.layers[-2].output)
data_path ='./Deep_Feature/data'
def Load_img(data_path):
    img_data = []
    label_name = []
    for img in os.listdir(data_path):
        label_name.append(img)
        fname = os.path.join(data_path,img)
        img = load_img(fname,target_size=(224,224))
        img = img_to_array(img)
        img_data.append(img)
    img_data = np.asarray(img_data)
    #img_data = np.expand_dims(img_data,axis=1)
    #print(img_data.shape)
    label = model.predict(img_data)
    return label,label_name
#load data groundtruth
data_groundtruth = './Deep_Feature/groundtruth'
def Load_groundtruth(data_groundtruth):
    data_ground = []
    for query in os.listdir(data_groundtruth):
        f_query = os.path.join(data_groundtruth,query)
        f_name_q = open (f_query,'r',encoding='utf-8')
        f_name_q = f_name_q.read()
        name_query = f_name_q.split()
        data_ground.append(name_query)
    return data_ground 
def load_img_query(query):
    img_q = load_img(query,target_size=(224,224))
    # img_q.show()
    img_q = img_to_array(img_q)
    # print(img_q.shape)
    #img_qt = np.asarray(img_q)
    img_qt = np.expand_dims(img_q,axis=0)
    # print(img_qt.shape)
    Label_q = model.predict(img_qt)
    # print(Label_q.shape)
    return Label_q
data,label = Load_img(data_path)
def cosin(x,y):
    return np.dot(x,y) / (np.sqrt(np.dot(x,x)) * np.sqrt(np.dot(y,y)))
#L2
def L2(x,y):
    return np.sqrt(np.sum((x-y) ** 2))
#L1
def L1(x,y):
    return np.sum(np.abs(x-y))
#Dot
def Dot(x,y):
    return np.dot(x,y)

def load_query():
    for i in Load_groundtruth(data_groundtruth):
        for idex in i:
            query = data_path + "/" + str(idex)
            print('Query : ',idex) 
            y = load_img_query(query)
            x = data
########################################
            print('\nUsing L1: ')
            l1 = [L1(x,y) for x in data]
            metric = sorted(l1)[:5]
            print(metric)
            l1 = np.argsort(l1)[:5]
            for i in l1:
                print(label[i])
#################################
            print('\nUsing L2: ')
            l2 = [L2(x,y) for x in data]
            metric = sorted(l2)[:5]
            print(metric)
            l2 = np.argsort(l2)[:5]
            for i in l2:
                print(label[i])
##################################
            x = np.array(x[0])
            y = np.array(y[0])
            print('\nUsing Dot: ')
            dot = [Dot(x,y) for x in data]
            metric = sorted(dot)[:5]
            print(metric)
            dot = np.argsort(dot)[::-1][:5]
            for i in dot:
                print(label[i])
# ###########################
            print('\nUsing Cos: ')
            Cosin = [cosin(x,y) for x in data]
            metric = sorted(Cosin)[:5]
            print(metric)
            Cosin = np.argsort(Cosin)[::-1][:5]
            for i in Cosin:
                print(label[i])
load_query()



    



